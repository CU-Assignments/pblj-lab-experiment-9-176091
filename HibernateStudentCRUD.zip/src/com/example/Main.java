package com.example;

public class Main {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        Student s1 = new Student("Sarthak Rana", "sarthak@example.com");
        dao.addStudent(s1);

        Student fetched = dao.getStudent(s1.getId());
        System.out.println("Fetched: " + fetched.getName() + ", " + fetched.getEmail());

        dao.updateStudent(fetched.getId(), "updated_email@example.com");
        dao.deleteStudent(fetched.getId());

        dao.close();
    }
}