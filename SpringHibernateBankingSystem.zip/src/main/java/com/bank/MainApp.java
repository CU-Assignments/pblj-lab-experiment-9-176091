package com.bank;

import com.bank.config.AppConfig;
import com.bank.service.BankService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        BankService service = context.getBean(BankService.class);
        service.transferMoney(1, 2, 500.0); // Transfer ₹500 from account 1 to account 2

        context.close();
    }
}