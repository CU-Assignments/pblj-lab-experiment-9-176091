package com.bank.service;

import com.bank.dao.AccountDAO;
import com.bank.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BankService {

    @Autowired
    private AccountDAO accountDAO;

    @Transactional
    public void transferMoney(int fromId, int toId, double amount) {
        Account fromAccount = accountDAO.getAccount(fromId);
        Account toAccount = accountDAO.getAccount(toId);

        if (fromAccount.getBalance() >= amount) {
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);
            accountDAO.updateAccount(fromAccount);
            accountDAO.updateAccount(toAccount);
        } else {
            throw new RuntimeException("Insufficient funds in source account.");
        }
    }
}